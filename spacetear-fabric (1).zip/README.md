# Space Tear Claw — Fabric 1.21.1 mod

Golden + silver claw that tears space. Requires Fabric Loader + Fabric API.

## Abilities
- **Right-click (tear-step):** raycasts ~24 blocks from crosshair, rips a portal burst, teleports you to the spot (safe-ground search). 3s cooldown, 1 durability.
- **Shift + right-click (tornado):** summons a Space-Tearing Tornado for ~10s at your look target. Pulls mobs in, slash-damage ticks + knock-up, gust + portal spiral with sweep/end-rod/dragon-breath slashes flying inside. 15s cooldown, 5 durability.
- Crouch inside your own tornado's eye to stand safe. Repairs with gold/iron ingots on an anvil. Found in the Combat tab.

## Play (Zalith Launcher 2, Lava Blaze X)
1. In Zalith, create/download a **1.21.1 + Fabric** instance (loader 0.16.x). Zalith fetches the Java 21 runtime itself — nothing special needed from you.
2. Put **Fabric API** (for 1.21.1) and the built `spacetear-1.0.0.jar` into the instance's `mods/` folder.
3. Launch. If the tornado ever feels heavy on mobile, tell me and I'll add a low-FX mode — particle counts are already kept moderate.

## Build (PC)
Needs Java 21 (NOT 17 — 1.21.1 requires 21).
1. `./gradlew build` (or `gradlew.bat build` on Windows). First run downloads everything.
2. Jar lands in `build/libs/`.
3. If Gradle complains about `fabric_version`, open `gradle.properties` and set it to the newest 1.21.1 build from https://fabricmc.net/develop/.

## Reskinning
Overwrite `src/main/resources/assets/spacetear/textures/item/space_tear_claw.png` (16x16 PNG, same name) and rebuild. The current texture is a placeholder.
