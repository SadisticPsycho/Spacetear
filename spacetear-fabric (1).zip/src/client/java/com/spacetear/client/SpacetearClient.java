package com.spacetear.client;

import com.spacetear.SpacetearMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class SpacetearClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(SpacetearMod.SPACE_TORNADO, SpaceTornadoRenderer::new);
	}
}
