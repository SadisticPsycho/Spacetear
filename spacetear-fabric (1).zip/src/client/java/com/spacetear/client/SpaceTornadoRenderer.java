package com.spacetear.client;

import com.spacetear.SpaceTornadoEntity;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.util.Identifier;

public class SpaceTornadoRenderer extends EntityRenderer<SpaceTornadoEntity> {

	private static final Identifier TEX = Identifier.of("spacetear", "textures/entity/space_tornado.png");

	public SpaceTornadoRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
	}

	@Override
	public Identifier getTexture(SpaceTornadoEntity entity) {
		return TEX;
	}
}
