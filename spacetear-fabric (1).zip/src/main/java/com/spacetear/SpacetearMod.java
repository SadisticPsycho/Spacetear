package com.spacetear;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class SpacetearMod implements ModInitializer {
	public static final String MODID = "spacetear";

	public static SpaceTearClawItem SPACE_TEAR_CLAW;
	public static EntityType<SpaceTornadoEntity> SPACE_TORNADO;

	public static Identifier id(String path) {
		return Identifier.of(MODID, path);
	}

	@Override
	public void onInitialize() {
		SPACE_TEAR_CLAW = Registry.register(Registries.ITEM, id("space_tear_claw"),
				new SpaceTearClawItem(new Item.Settings().maxCount(1).maxDamage(250).fireproof()));

		SPACE_TORNADO = Registry.register(Registries.ENTITY_TYPE, id("space_tornado"),
				FabricEntityTypeBuilder.create(SpawnGroup.MISC, SpaceTornadoEntity::new)
						.dimensions(EntityDimensions.fixed(3.0F, 6.0F))
						.trackRangeChunks(10)
						.trackedUpdateRate(1)
						.build());

		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(SPACE_TEAR_CLAW));
	}
}
