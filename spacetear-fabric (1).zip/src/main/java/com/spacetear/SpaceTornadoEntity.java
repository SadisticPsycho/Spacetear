package com.spacetear;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class SpaceTornadoEntity extends Entity {

	private int lifetime = 200;
	@Nullable
	private UUID ownerUuid;

	public SpaceTornadoEntity(EntityType<?> type, World world) {
		super(type, world);
		this.noClip = true;
	}

	public void setLifetime(int ticks) {
		this.lifetime = ticks;
	}

	public void setOwnerUuid(UUID id) {
		this.ownerUuid = id;
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		this.age = nbt.getInt("Age");
		this.lifetime = nbt.getInt("Lifetime");
		if (nbt.containsUuid("Owner")) this.ownerUuid = nbt.getUuid("Owner");
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putInt("Age", age);
		nbt.putInt("Lifetime", lifetime);
		if (ownerUuid != null) nbt.putUuid("Owner", ownerUuid);
	}

	@Override
	public void tick() {
		super.tick();

		if (getWorld().isClient) {
			clientParticles();
			return;
		}
		if (!(getWorld() instanceof ServerWorld server)) return;

		if (age >= lifetime) {
			server.spawnParticles(ParticleTypes.PORTAL, getX(), getY() + 2.0, getZ(),
					80, 1.5, 3.0, 1.5, 0.5);
			server.spawnParticles(ParticleTypes.GUST, getX(), getY() + 0.5, getZ(),
					6, 2.0, 1.0, 2.0, 0.1);
			server.playSound(null, getBlockPos(),
					SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.HOSTILE, 1.0F, 0.6F);
			discard();
			return;
		}

		double radius = 6.0;
		Box box = new Box(
				getX() - radius, getY() - 1.0, getZ() - radius,
				getX() + radius, getY() + 7.0, getZ() + radius);

		DamageSource slash = getDamageSources().magic();

		for (Entity e : getWorld().getOtherEntities(this, box)) {
			if (e == this) continue;
			if (ownerUuid != null && e.getUuid().equals(ownerUuid)
					&& e instanceof LivingEntity le && le.isSneaking()) {
				continue; // owner can crouch to stand in the eye safely
			}
			Vec3d to = new Vec3d(getX() - e.getX(), 0, getZ() - e.getZ());
			double dist = Math.max(0.5, to.length());
			Vec3d inward = to.normalize();
			double pull = 0.55 * (1.0 - dist / (radius + 1.0)) + 0.12;
			Vec3d tangent = new Vec3d(-inward.z, 0, inward.x);
			Vec3d motion = inward.multiply(pull).add(tangent.multiply(0.45));
			e.setVelocity(e.getVelocity().add(motion).add(0, 0.08, 0));
			e.velocityModified = true;
			e.fallDistance = 0;

			if (dist < 3.5 && age % 10 == 0 && e instanceof LivingEntity le) {
				le.damage(server, slash, 4.0F);
				le.setVelocity(le.getVelocity().add(
						-inward.x * 0.4, 0.55, -inward.z * 0.4));
				le.velocityModified = true;
				server.spawnParticles(ParticleTypes.SWEEP_ATTACK,
						le.getX(), le.getY() + 1.0, le.getZ(), 2, 0.4, 0.6, 0.4, 0);
				server.spawnParticles(ParticleTypes.DRAGON_BREATH,
						le.getX(), le.getY() + 1.0, le.getZ(), 6, 0.3, 0.5, 0.3, 0.05);
			}
		}

		if (age % 40 == 0) {
			server.playSound(null, getBlockPos(),
					SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.HOSTILE, 0.5F, 0.5F);
		}
	}

	private void clientParticles() {
		double t = age * 0.35;
		for (int i = 0; i < 10; i++) {
			double h = (age * 0.12 + i * 0.55) % 6.0;
			double r = 0.5 + h * 0.38;
			double a = t + i * (Math.PI * 2.0 / 10.0);
			double x = getX() + Math.cos(a) * r;
			double z = getZ() + Math.sin(a) * r;
			double y = getY() + h;
			getWorld().addParticle(ParticleTypes.PORTAL, x, y, z,
					-Math.sin(a) * 0.6, 0.35, Math.cos(a) * 0.6);
			if ((i + age) % 3 == 0) {
				getWorld().addParticle(ParticleTypes.GUST, x, y, z, 0, 0.1, 0);
			}
			if ((i * 7 + age) % 11 == 0) {
				getWorld().addParticle(ParticleTypes.REVERSE_PORTAL, x, y, z,
						Math.cos(a) * 0.4, 0.2, Math.sin(a) * 0.4);
			}
		}
		for (int i = 0; i < 4; i++) {
			double a = random.nextDouble() * Math.PI * 2.0;
			double r = 0.4 + random.nextDouble() * 1.6;
			double y = getY() + random.nextDouble() * 5.0;
			double x = getX() + Math.cos(a) * r;
			double z = getZ() + Math.sin(a) * r;
			double pick = random.nextDouble();
			if (pick < 0.45) {
				getWorld().addParticle(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0, 0);
			} else if (pick < 0.75) {
				getWorld().addParticle(ParticleTypes.END_ROD, x, y, z,
						(random.nextDouble() - 0.5) * 1.5,
						(random.nextDouble() - 0.5) * 1.5,
						(random.nextDouble() - 0.5) * 1.5);
			} else {
				getWorld().addParticle(ParticleTypes.DRAGON_BREATH, x, y, z,
						(random.nextDouble() - 0.5), 0.4, (random.nextDouble() - 0.5));
			}
		}
		for (int i = 0; i < 6; i++) {
			double a = t * 1.4 + i * (Math.PI * 2.0 / 6.0);
			getWorld().addParticle(ParticleTypes.WITCH,
					getX() + Math.cos(a) * 2.6, getY() + 0.15, getZ() + Math.sin(a) * 2.6,
					0, 0.05, 0);
		}
	}
}
