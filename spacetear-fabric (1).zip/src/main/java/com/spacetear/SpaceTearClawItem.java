package com.spacetear;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public class SpaceTearClawItem extends Item {

	private static final double TELEPORT_RANGE = 24.0;
	private static final int TELEPORT_COOLDOWN = 60; // 3s
	private static final int TORNADO_COOLDOWN = 300; // 15s
	private static final int TORNADO_LIFETIME = 200; // 10s

	public SpaceTearClawItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		if (world.isClient) {
			return TypedActionResult.success(stack, true);
		}
		ServerWorld server = (ServerWorld) world;
		if (user.isSneaking()) {
			summonTornado(server, user, stack, hand);
		} else {
			tearStep(server, user, stack, hand);
		}
		return TypedActionResult.success(stack, false);
	}

	// ---- Ability 1: tear space, teleport to look target ----
	private void tearStep(ServerWorld server, PlayerEntity player, ItemStack stack, Hand hand) {
		if (player.getItemCooldownManager().isCoolingDown(this)) return;

		Vec3d eye = player.getCameraPosVec(1.0F);
		Vec3d look = player.getRotationVec(1.0F);
		BlockHitResult hit = server.raycast(new RaycastContext(
				eye, eye.add(look.multiply(TELEPORT_RANGE)),
				RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, player));

		BlockPos target;
		if (hit.getType() == HitResult.Type.BLOCK) {
			target = hit.getBlockPos().up();
		} else {
			target = BlockPos.ofFloored(eye.add(look.multiply(TELEPORT_RANGE)));
		}
		target = findSafeSpot(server, target);
		if (target == null) {
			server.spawnParticles(ParticleTypes.SMOKE,
					player.getX(), player.getY() + 1.0, player.getZ(),
					12, 0.3, 0.5, 0.3, 0.02);
			return;
		}

		Vec3d from = player.getPos();
		server.spawnParticles(ParticleTypes.PORTAL, from.x, from.y + 1.0, from.z,
				40, 0.5, 1.0, 0.5, 0.6);
		server.spawnParticles(ParticleTypes.REVERSE_PORTAL, from.x, from.y + 1.0, from.z,
				20, 0.4, 0.8, 0.4, 0.25);
		server.playSound(null, player.getBlockPos(),
				SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.6F, 1.4F);

		double tx = target.getX() + 0.5;
		double ty = target.getY();
		double tz = target.getZ() + 0.5;

		if (player instanceof ServerPlayerEntity sp) {
			sp.teleport(server, tx, ty, tz, sp.getYaw(), sp.getPitch());
		} else {
			player.refreshPositionAndAngles(tx, ty, tz, player.getYaw(), player.getPitch());
		}

		server.spawnParticles(ParticleTypes.PORTAL, tx, ty + 1.0, tz,
				40, 0.5, 1.0, 0.5, 0.6);
		server.spawnParticles(ParticleTypes.END_ROD, tx, ty + 1.0, tz,
				12, 0.4, 0.8, 0.4, 0.05);
		for (int i = 0; i < 6; i++) {
			double a = server.random.nextDouble() * Math.PI * 2.0;
			server.spawnParticles(ParticleTypes.SWEEP_ATTACK,
					tx + Math.cos(a) * 1.2, ty + 1.0 + server.random.nextDouble() * 1.5, tz + Math.sin(a) * 1.2,
					1, 0, 0, 0, 0);
		}
		server.playSound(null, target,
				SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.6F, 1.2F);
		server.playSound(null, target,
				SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.8F, 1.1F);

		player.getItemCooldownManager().set(this, TELEPORT_COOLDOWN);
		stack.damage(1, player, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
	}

	private BlockPos findSafeSpot(ServerWorld server, BlockPos pos) {
		BlockPos.Mutable m = pos.mutableCopy();
		for (int i = 0; i < 8; i++) {
			if (server.getBlockState(m).getCollisionShape(server, m).isEmpty()
					&& server.getBlockState(m.up()).getCollisionShape(server, m.up()).isEmpty()) {
				break;
			}
			m.move(0, 1, 0);
		}
		for (int i = 0; i < 12; i++) {
			if (!server.getBlockState(m.down()).getCollisionShape(server, m.down()).isEmpty()) {
				break;
			}
			m.move(0, -1, 0);
			if (server.isOutOfHeightLimit(m)) return null;
		}
		if (!server.getBlockState(m).getCollisionShape(server, m).isEmpty()) return null;
		if (!server.getBlockState(m.up()).getCollisionShape(server, m.up()).isEmpty()) return null;
		if (server.isOutOfHeightLimit(m)) return null;
		return m.toImmutable();
	}

	// ---- Ability 2: summon space-tearing tornado ----
	private void summonTornado(ServerWorld server, PlayerEntity player, ItemStack stack, Hand hand) {
		if (player.getItemCooldownManager().isCoolingDown(this)) return;

		Vec3d eye = player.getCameraPosVec(1.0F);
		Vec3d look = player.getRotationVec(1.0F);
		BlockHitResult hit = server.raycast(new RaycastContext(
				eye, eye.add(look.multiply(TELEPORT_RANGE)),
				RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, player));

		Vec3d at;
		if (hit.getType() == HitResult.Type.BLOCK) {
			at = Vec3d.ofCenter(hit.getBlockPos().up());
		} else {
			at = eye.add(look.multiply(6.0));
		}

		SpaceTornadoEntity tornado = new SpaceTornadoEntity(SpacetearMod.SPACE_TORNADO, server);
		tornado.refreshPositionAndAngles(at.x, at.y, at.z, server.random.nextFloat() * 360.0F, 0.0F);
		tornado.setLifetime(TORNADO_LIFETIME);
		tornado.setOwnerUuid(player.getUuid());
		server.spawnEntity(tornado);

		server.spawnParticles(ParticleTypes.REVERSE_PORTAL,
				player.getX(), player.getY() + 1.0, player.getZ(),
				30, 0.4, 0.8, 0.4, 0.4);
		server.spawnParticles(ParticleTypes.PORTAL, at.x, at.y + 1.0, at.z,
				60, 1.0, 2.0, 1.0, 0.6);
		server.spawnParticles(ParticleTypes.GUST, at.x, at.y + 0.5, at.z,
				8, 1.5, 0.5, 1.5, 0.1);
		server.playSound(null, BlockPos.ofFloored(at),
				SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0F, 0.7F);
		server.playSound(null, BlockPos.ofFloored(at),
				SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.8F, 0.8F);

		player.getItemCooldownManager().set(this, TORNADO_COOLDOWN);
		stack.damage(5, player, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
	}

	@Override
	public boolean canRepair(ItemStack stack, ItemStack ingredient) {
		return ingredient.isOf(Items.GOLD_INGOT) || ingredient.isOf(Items.IRON_INGOT);
	}
}
